package com;

import java.util.ArrayList;



public class ViewReportBean {
	
	public static ArrayList<ReportPOJO> viewReport(ReportPOJO reportPOJO)
	{
		ArrayList<ReportPOJO> pojoList1=new ArrayList<>();
		String claim_type=reportPOJO.getClaim_type();
		ArrayList<ReportPOJO> pojoList=ViewReportDAO.viewReport(reportPOJO);
		for (ReportPOJO reportPOJO2 : pojoList) {
			String claims[]=reportPOJO2.getClaim_type().split(",");
			for(int i=0;i<claims.length;i++)
			{
				if(claims[i].equalsIgnoreCase(claim_type))
					pojoList1.add(reportPOJO2);
			}
			
		}
		return pojoList1;
	}

}
