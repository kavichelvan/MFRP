package com;


	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.sql.Statement;





	public class ChangePasswordDAO {
		static{
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		public static String changePassword(ChangePasswordPOJO changePasswordPOJO)
		{
			String flag="fail";
			try {
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Healthinsurance","root","root");
				PreparedStatement pst=con.prepareStatement("update login set password=? where user_id=?;");
				pst.setString(1, changePasswordPOJO.getPassword());
				pst.setInt(2, Integer.parseInt(changePasswordPOJO.getUserId()));
				pst.execute();
				flag="success";
					
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				flag="fail";
			}
			return flag;
			
		}

	}