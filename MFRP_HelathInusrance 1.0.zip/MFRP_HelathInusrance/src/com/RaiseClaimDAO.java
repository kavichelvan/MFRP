package com;





import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;

import sun.java2d.pipe.SpanShapeRenderer.Simple;


public class RaiseClaimDAO {
	static Connection con;
	static{
	try {
		Class.forName("com.mysql.jdbc.Driver");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	try {
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Healthinsurance","root","root");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
      public static String checkDB(RaiseClaimPOJO pojo)
      {
    	  String a1="Failure";
    	  
     
            try {
                  
            	Statement smt = null;	
				
            	Statement st=con.createStatement();
				ResultSet rst=st.executeQuery("select * from claims;"); 
				int count=1;
				while(rst.next())
				{
					count++;
				}
				String count1=Integer.toString(count);
				String count2=count1;
                  pojo.setClaimId(count2);
                 smt=con.createStatement();
                 
                  smt.executeUpdate("insert into claims(claim_id,user_id,claim_type,claim_amount,claim_description,claim_date,claim_status) values ("+count2+","+pojo.getUser_id()+",'"+pojo.getClaim_type()+"',"+pojo.getClaim_amount()+",'"+pojo.getClaim_description()+"','"+pojo.getClaim_date()+"','"+pojo.getClaim_status()+"');");
                 
                  a1="success";
                  
               
            }catch(Exception e)
			{
			e.printStackTrace();
			}
			return a1;
			
            
            
      
}}


