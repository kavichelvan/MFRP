package com;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class LoginDAO {
	static{
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static boolean checkUser(LoginPOJO login)
	{
		boolean flag=false;
   		
		
			Connection con;
			try {
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Healthinsurance","root","root");
				Statement st=con.createStatement();
				ResultSet rst=st.executeQuery("select * from login where status='Active';");
				
				while(rst.next())
				{
					String user=rst.getString(1);
					String pass=rst.getString(2);
					String password=login.getPassword();
					String userId=login.getUserId();
					if((user.equals(userId)) && (pass.equals(password)))
					{
						flag=true;
					}
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				flag=false;
			}
			
			 
		
		return flag; 
		
	}
	
	
	public static String getRole(String userId)
	{
		String role="User";
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Healthinsurance","root","root");
			Statement st=con.createStatement();
			ResultSet rst=st.executeQuery("select * from login where status='Active';");
				while(rst.next())
				{
					String user=rst.getString(1);
					String role1=rst.getString(14);
					
					if(user.equals(userId))
					{
						role=rst.getString(15);
					}
				}
				
				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return role;
		
	}
	

}