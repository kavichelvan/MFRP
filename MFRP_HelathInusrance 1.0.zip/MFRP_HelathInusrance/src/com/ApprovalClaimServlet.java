package com;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class ApprovalClaimServlet extends HttpServlet {
	
	List<ApprovalClaimPOJO> pojoList=null;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		if(request.getParameter("flow1")!=null)
		{
			String fromdate=request.getParameter("from_date");
			String todate=request.getParameter("to_date");

			ApprovalClaimPOJO approvePOJO=new ApprovalClaimPOJO(fromdate, todate);
			pojoList=ApprovalClaimBean.claimDetails(approvePOJO);
			request.setAttribute("pojoList", pojoList);

			String dest="ApprovalClaimJSP.jsp";
			RequestDispatcher dispatcher=request.getRequestDispatcher(dest);
			dispatcher.forward(request, response);
		}
		
		
		if(request.getParameter("opt")!=null)
		{
			
			String claimId=request.getParameter("claimId");
			String opt=request.getParameter("opt");
			if(opt.equals("Yes"))
			{
				System.out.println("yes");
				boolean result=ApprovalClaimBean.updateClaim(claimId);
				if(result==true)
				{
					System.out.println("true");
					request.setAttribute("status","success");
					request.setAttribute("id",claimId);
				}
				else
					
				{
					System.out.println("false");
					request.setAttribute("status","failure");
					request.setAttribute("id",claimId);
				}
				
				request.setAttribute("pojoList", pojoList);
				String dest="ApprovalClaimJSP.jsp";
				RequestDispatcher dispatcher=request.getRequestDispatcher(dest);
				dispatcher.forward(request, response);
			}
			else
			{
				System.out.println("yes");

				request.setAttribute("pojoList", pojoList);
				String dest="ApprovalClaimJSP.jsp";
				RequestDispatcher dispatcher=request.getRequestDispatcher(dest);
				dispatcher.forward(request, response);
			}
			
			
		}
		

	}




}
