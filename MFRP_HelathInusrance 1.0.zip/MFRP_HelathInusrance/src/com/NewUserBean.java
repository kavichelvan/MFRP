package com;
import java.util.Arrays;




public class NewUserBean {
	public static String newUser(NewUserPOJO newuserPOJO)
	{
		String annInc=newuserPOJO.getAnnualIncome();
		String usid=newuserPOJO.getUserId();
		String pass=newuserPOJO.getPassword();
		String pa="^(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[#@$%&])(?=\\S+$).{8,}$";
		char[] cp=pass.toCharArray();
		char[] p=new char[cp.length];
		String pattern="[0-9]+";
		String returnString="null";
		if(annInc.matches(pattern) && usid.matches(pattern) && pass.matches(pa) )
		{
			for(int i=0;i<pass.length();i++)
			{
				int a=cp[i];
				a++;
				p[i]=(char)a;
			}
			String password=String.valueOf(p);
			newuserPOJO.setPassword(password);
			return NewUserDAO.newUser(newuserPOJO);
		}
		else
		{
			
			if(!(annInc.matches(pattern)) && !(usid.matches(pattern)) && !pass.matches(pa))
			{
				returnString="ai-ui-pass";
			}
			else if(!(annInc.matches(pattern)) && !(usid.matches(pattern)))
			{
				returnString="ai-ui";	
			}
			else if(!(annInc.matches(pattern)) && !pass.matches(pa))
			{
				returnString="ai-pass";	
			}
			else if(!(usid.matches(pattern))&& !pass.matches(pa))
			{
				returnString="ui-pass";	
			}
			else if(!(annInc.matches(pattern)))
			{
				returnString="ai";

			}
			else if(!(usid.matches(pattern)))
			{
				returnString="ui";
			}
			else if(!pass.matches(pa))
			{
				returnString="pass";
			}
		}
		return returnString;
		
	}
}