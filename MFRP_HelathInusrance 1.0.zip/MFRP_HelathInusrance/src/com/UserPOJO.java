package com;

public class UserPOJO {
	private String userId;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public UserPOJO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public UserPOJO(String userId) {
		super();
		this.userId = userId;
		
	}
	

}
