package com;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userId=request.getParameter("name");
		String pass=request.getParameter("pass");		 
		 response.setContentType("text/html");
			HttpSession session=request.getSession();
			session.setAttribute("user",userId);
	   		LoginPOJO loginPOJO=new LoginPOJO(userId, pass);
	   		if(LoginBean.checkUser(loginPOJO))
	   		{							 
	   			String role=LoginBean.getRole(userId);
	   			if(role.equalsIgnoreCase("User"))
	   			{
				RequestDispatcher dispatcher=request.getRequestDispatcher("User.jsp");
			
				dispatcher.forward(request, response);
	   			}
	   			else
	   			{
	   				RequestDispatcher dispatcher=request.getRequestDispatcher("Admin.jsp");
	   				
					dispatcher.forward(request, response);	
	   			}
	   			
			}
			 else
			{
				RequestDispatcher dispatcher=request.getRequestDispatcher("Failure.html");								 
				dispatcher.forward(request, response);
								 
			}
		}
	   	

}
