package com;

import java.util.Iterator;

public class ApprovalClaimPOJO {

	private String from_date;
	private String to_date;
	private String claim_id;
	private int user_id;
	private String claim_type;
	private Double claim_amount;
	private String claim_description;
	private String claim_date;
	private String claim_status;
	
	public ApprovalClaimPOJO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ApprovalClaimPOJO(String from_date, String to_date) {
		super();
		this.from_date = from_date;
		this.to_date = to_date;
	}
	public ApprovalClaimPOJO(String claim_id, int user_id, String claim_type,
			Double claim_amount, String claim_description, String claim_date,
			String claim_status) {
		super();
		this.claim_id = claim_id;
		this.user_id = user_id;
		this.claim_type = claim_type;
		this.claim_amount = claim_amount;
		this.claim_description = claim_description;
		this.claim_date = claim_date;
		this.claim_status = claim_status;
	}
	public String getFrom_date() {
		return from_date;
	}
	public void setFrom_date(String from_date) {
		this.from_date = from_date;
	}
	public String getTo_date() {
		return to_date;
	}
	public void setTo_date(String to_date) {
		this.to_date = to_date;
	}
	public String getClaim_id() {
		return claim_id;
	}
	public void setClaim_id(String claim_id) {
		this.claim_id = claim_id;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getClaim_type() {
		return claim_type;
	}
	public void setClaim_type(String claim_type) {
		this.claim_type = claim_type;
	}
	public Double getClaim_amount() {
		return claim_amount;
	}
	public void setClaim_amount(Double claim_amount) {
		this.claim_amount = claim_amount;
	}
	public String getClaim_description() {
		return claim_description;
	}
	public void setClaim_description(String claim_description) {
		this.claim_description = claim_description;
	}
	public String getClaim_date() {
		return claim_date;
	}
	public void setClaim_date(String claim_date) {
		this.claim_date = claim_date;
	}
	public String getClaim_status() {
		return claim_status;
	}
	public void setClaim_status(String claim_status) {
		this.claim_status = claim_status;
	}
	
	
	
}
