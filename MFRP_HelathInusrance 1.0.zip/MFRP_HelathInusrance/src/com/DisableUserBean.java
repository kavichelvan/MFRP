package com;

import java.util.ArrayList;

public class DisableUserBean {
	public static ArrayList<UserPOJO> DisableUser()
	{
		
		return DisableUserDAO.DisableUser();
	}

	
		public static Boolean UpdateUser(Integer userid)
		{
		
			return DisableUserDAO.UpdateUser(userid);
		}

	
}
