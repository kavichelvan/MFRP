package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;


public class ApprovalClaimDAO {
	static Connection con;
	static
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/claimsDB","root","root");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

	public static List<ApprovalClaimPOJO> checkDB(String fd,String td) {

		List<ApprovalClaimPOJO> pojolist=new ArrayList<>();
		Statement st =null;  
		ResultSet rst=null;

		try {
			if(con!=null) {                                               
	
				st = con.createStatement();
				rst=st.executeQuery("select c.claim_id,cd.user_id,ct.name,cd.claim_amount,cd.claim_description,c.claim_date,cs.status_type from claims c join claim_type ct on c.claim_type_id=ct.claim_type_id join claim_details cd on c.claim_id=cd.claim_id join claim_status cs on cd.claim_status_id=cs.claim_status_id where c.claim_date between '"+fd+"' and '"+td+"';"); 
				/*st=st.executeQuery("select c.claim_id,cd.user_id,ct.name,cd.claim_amount,cd.claim_description,c.claim_date,cs.status_type from claims as c "
						+ "join claim_type as ct on c.claim_type_id=ct.claim_type_id join claim_details as cd on c.claim_id=cd.claim_id join claim_status as cs on cd.claim_status_id=cs.claim_status_id"
						+ "where c.claim_date between '"+fd+"' and '"+td+"';"); */
			}
			while(rst.next())
			{
				
				ApprovalClaimPOJO apojo=new ApprovalClaimPOJO(rst.getString(1),rst.getInt(2),rst.getString(3),rst.getDouble(4),rst.getString(5),rst.getString(6),rst.getString(7));
				pojolist.add(apojo);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<ApprovalClaimPOJO> list=new ArrayList<>();
		Iterator<ApprovalClaimPOJO> it=pojolist.iterator();
		ApprovalClaimPOJO apPOJO;
		String claimid="",claimid1="",claimtype="";
		
		
		while (it.hasNext()) {
			ApprovalClaimPOJO approvalClaimPOJO = (ApprovalClaimPOJO) it.next();
			claimid=approvalClaimPOJO.getClaim_id();
			claimtype=approvalClaimPOJO.getClaim_type();
			int count=0;
			Iterator<ApprovalClaimPOJO> it1=pojolist.iterator();
			while (it1.hasNext()) {
				ApprovalClaimPOJO acPOJO = (ApprovalClaimPOJO) it1.next();
				if(claimid.equals(acPOJO.getClaim_id()) && claimtype!=acPOJO.getClaim_type())
				{
					count++;
					if(count!=0)
						claimtype+=", ";
					claimtype+=acPOJO.getClaim_type();
					
				}
			}
			apPOJO=new ApprovalClaimPOJO(approvalClaimPOJO.getClaim_id(),approvalClaimPOJO.getUser_id(),claimtype,approvalClaimPOJO.getClaim_amount(),approvalClaimPOJO.getClaim_description(),approvalClaimPOJO.getClaim_date(),approvalClaimPOJO.getClaim_status());
			list.add(apPOJO);
		}
		return list;
	}

	
	public static boolean updateClaim(String claimID)
	{
		Statement st =null;  
		int result=0;
		boolean flag=false;
		try {
			if(con!=null) {                                               
	
				st = con.createStatement();
				result=st.executeUpdate("update claims set claim_status='APPROVED' where claim_id='"+claimID+"'"); 
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (result==1)
			flag=true;
		
		return flag;
	}
	
}

