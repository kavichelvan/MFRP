package com;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;

public class NewUserDAO {
	static Connection con;
	static{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Healthinsurance","root","root");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static String newUser(NewUserPOJO newuserPOJO)
	{
		String flag="false";
   		
		
		
	try {
				
				Statement stmt=con.createStatement();
				ResultSet rst=stmt.executeQuery("select user_id from login;");
				
				while(rst.next())
				{
					String user=rst.getString(1);
					if(user.equals(newuserPOJO.getUserId()))
					{
						flag=null;
						return flag;
					}
					
				}
				
											
				Statement st=con.createStatement();
				
				st.executeUpdate("insert into login(User_id,Password,First_name,Middle_Name,Last_name,Sex,Dob,Qualification,Annual_income,Address,Phone_number,Mobile_number,Mail_id) values("+Integer.parseInt(newuserPOJO.getUserId())+",'"+ newuserPOJO.getPassword() +"','"+ newuserPOJO.getFirstName()+"','"+ newuserPOJO.getMiddleName()+
						"','" + newuserPOJO.getLastName() +"','" + newuserPOJO.getSex()+"','" + newuserPOJO.getDob() +"','" + newuserPOJO.getQualification()+"'," +newuserPOJO.getAnnualIncome()+",'" + newuserPOJO.getAddress()
						+"','" + newuserPOJO.getPhoneNumber()+"','" + newuserPOJO.getMobileNumber()+"','" + newuserPOJO.getMailId()+"')");
				flag="true";
				
			} catch (SQLException e) {
				flag="false";
				e.printStackTrace();
			}
			
			 
		
		return flag; 
		
		
	}
}