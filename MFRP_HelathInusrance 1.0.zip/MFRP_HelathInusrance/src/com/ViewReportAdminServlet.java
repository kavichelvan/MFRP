package com;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ReportPOJO;
import com.ViewReportBean;

/**
 * Servlet implementation class ViewReportServlet
 */
@WebServlet("/ViewReportAdminServlet")
public class ViewReportAdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	 String fromdate=request.getParameter("fromdate");
	 String todate=request.getParameter("todate");
	 String claim_type=request.getParameter("claim_type");
	
	 ReportPOJO reportPOJO=new ReportPOJO(claim_type, fromdate, todate);
	 ArrayList<ReportPOJO> pojoList=ViewReportAdminBean.viewReport(reportPOJO);
	 request.setAttribute("pojoList", pojoList);
	 String dest="ViewReportAdminJSP.jsp";
	RequestDispatcher dispatcher=request.getRequestDispatcher(dest);
	 dispatcher.forward(request, response);
	 
	 
	}

	
	
}
