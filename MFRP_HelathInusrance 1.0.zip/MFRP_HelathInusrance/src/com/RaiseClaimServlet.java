package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/RaiseClaimServlet")
public class RaiseClaimServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public RaiseClaimServlet() {
		super();
	}

	public void init(ServletConfig config) throws ServletException {

	}

	public void destroy() {

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String s="";
        HttpSession session=request.getSession();
        String id=(String)session.getAttribute("user");
		RaiseClaimPOJO pojo=new RaiseClaimPOJO();

		String[] claimtype=request.getParameterValues("claimtype");
		if(claimtype==null)
		{
			pojo.setClaim_type(null);
		}
		else
		{
			int c=1;
			for (String string : claimtype) {
				if(c!=1)
					s+=",";
				s+=string;
				c++;
			}
			pojo.setClaim_type(s);
		}

		String amount=request.getParameter("amount");
		
		String description=request.getParameter("description");
		pojo.setUser_id(Integer.parseInt(id));
		pojo.setClaim_amount((amount));
		pojo.setClaim_description(description);

		String result=RaiseClaimBean.claimRequest(pojo);
		RequestDispatcher rd=request.getRequestDispatcher("RaiseClaimSuccess.jsp"); 	
	
		if(result.equals("success"))
		{
			request.setAttribute("pojo", pojo);
			rd.forward(request, response);
		}
		else 
		{
			rd=request.getRequestDispatcher("RaiseClaim.jsp");
			request.setAttribute("error",result);
			rd.forward(request, response);
		}
					
	}

}
