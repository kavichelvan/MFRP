package com;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/NewUserServlet")
public class NewUserServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userId=request.getParameter("userid");
		String password=request.getParameter("password");
		String firstName=request.getParameter("firstname");
		String middleName=request.getParameter("middlename");
		String lastName=request.getParameter("lastname");
		String sex=request.getParameter("sex");
		String dob=request.getParameter("date");
		String qualification=request.getParameter("qualification");
		String annualIncome=request.getParameter("annualincome");
		String address=request.getParameter("address");
		String phoneNumber=request.getParameter("phone");
		String mobileNumber=request.getParameter("mobile");
		String mailId=request.getParameter("mail");
		
			
	   	NewUserPOJO newuserPOJO;
		newuserPOJO = new NewUserPOJO(userId, password, firstName,middleName, lastName, sex,dob, qualification, annualIncome, address, phoneNumber, mobileNumber, mailId);
		String flag=NewUserBean.newUser(newuserPOJO);
		RequestDispatcher dispatcher=request.getRequestDispatcher("NewUserResult.jsp");
		if(flag==null)
		{			
			request.setAttribute("userResult", "Policy id is already registered. Please try again with a different Policy number.");
		}
		else if(flag.equals("true"))
		{
			request.setAttribute("userResult", "New User registered successfully.<a href='http://localhost:7071/com/Login.html'>Click here</a> to login with new user ID.");			
		}
		else if(flag.equals("false"))
		{
			request.setAttribute("userResult", "Registration Failed!! Please try again");
		}
		else
		{
			if(flag.equals("ai-ui-pass"))
			{
				request.setAttribute("error", "User Id should be in numbers<br>Annual Income should be in numbers<br>password should match the specifications");
				dispatcher=request.getRequestDispatcher("NewUser.jsp");
			}
			else if(flag.equals("ai-ui"))
			{
				request.setAttribute("error", "User Id should be in numbers<br>Annual Income should be in numbers");
				dispatcher=request.getRequestDispatcher("NewUser.jsp");
			}
			else if(flag.equals("ui-pass"))
			{
				request.setAttribute("error", "User Id should be in numbers<br>password should match the specifications");
				dispatcher=request.getRequestDispatcher("NewUser.jsp");
			}
			else if(flag.equals("ai-pass"))
			{
				request.setAttribute("error", "Annual Income should be in numbers<br>password should match the specifications");
				dispatcher=request.getRequestDispatcher("NewUser.jsp");
			}
			else if(flag.equals("ai"))
			{
				request.setAttribute("error", "Annual Income should be in numbers");
				dispatcher=request.getRequestDispatcher("NewUser.jsp");
			}
			else if(flag.equals("ui"))
			{
				request.setAttribute("error", "User Id should be in numbers");
				dispatcher=request.getRequestDispatcher("NewUser.jsp");
			}
			else if(flag.equals("pass"))
			{
				request.setAttribute("error", "password should match the specifications");
				dispatcher=request.getRequestDispatcher("NewUser.jsp");
			}
				
		}
										 
		dispatcher.forward(request, response);
	}
	}