package com;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;


public class ApprovalClaimBean {

	public static List<ApprovalClaimPOJO> claimDetails(ApprovalClaimPOJO apojo){
		List<ApprovalClaimPOJO> claimlist=new ArrayList<>();
		//SimpleDateFormat sdf=new SimpleDateFormat();
		//ApprovalClaimDAO adao=new ApprovalClaimDAO();
		List<ApprovalClaimPOJO> clmlist=new ArrayList<>();
		
		String from_date=apojo.getFrom_date();
		String to_date=apojo.getTo_date();
		
		clmlist=ApprovalClaimDAO.checkDB(from_date,to_date);
		
		
		return clmlist;

	}
	
	public static boolean updateClaim(String claimID)
	{
		return(ApprovalClaimDAO.updateClaim(claimID));
	}

}
