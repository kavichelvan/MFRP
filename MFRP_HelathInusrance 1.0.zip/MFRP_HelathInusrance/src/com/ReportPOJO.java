package com;

import java.util.Date;

public class ReportPOJO {

	private Integer claim_id;
	private Integer user_id;
	private String claim_type;
	private Double claim_amount;
	private String claim_description;
	private String fromDate;
	private String toDate;
	private String claim_date;
	private String claim_status;
	public Integer getClaim_id() {
		return claim_id;
	}
	public void setClaim_id(Integer claim_id) {
		this.claim_id = claim_id;
	}
	public Integer getUser_id() {
		return user_id;
	}
	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}
	public String getClaim_type() {
		return claim_type;
	}
	public void setClaim_type(String claim_type) {
		this.claim_type = claim_type;
	}
	public Double getClaim_amount() {
		return claim_amount;
	}
	public void setClaim_amount(Double claim_amount) {
		this.claim_amount = claim_amount;
	}
	public String getClaim_description() {
		return claim_description;
	}
	public void setClaim_description(String claim_description) {
		this.claim_description = claim_description;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getClaim_date() {
		return claim_date;
	}
	public void setClaim_date(String claim_date) {
		this.claim_date = claim_date;
	}
	public String getClaim_status() {
		return claim_status;
	}
	public void setClaim_status(String claim_status) {
		this.claim_status = claim_status;
	}
	public ReportPOJO(Integer claim_id, Integer user_id, String claim_type,
			Double claim_amount, String claim_description, String fromDate,
			String toDate, String claim_date, String claim_status) {
		super();
		this.claim_id = claim_id;
		this.user_id = user_id;
		this.claim_type = claim_type;
		this.claim_amount = claim_amount;
		this.claim_description = claim_description;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.claim_date = claim_date;
		this.claim_status = claim_status;
	}
	public ReportPOJO(Integer user_id, String claim_type, String fromDate,
			String toDate) {
		super();
		this.user_id = user_id;
		this.claim_type = claim_type;
		this.fromDate = fromDate;
		this.toDate = toDate;
	}
	public ReportPOJO(String claim_type, String fromDate, String toDate) {
		super();
		this.claim_type = claim_type;
		this.fromDate = fromDate;
		this.toDate = toDate;
	}
	
	
}
