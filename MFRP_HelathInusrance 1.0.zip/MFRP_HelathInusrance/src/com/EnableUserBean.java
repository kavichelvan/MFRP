package com;

import java.util.ArrayList;

public class EnableUserBean {
	
	public static ArrayList<UserPOJO> EnableUser()
	{
		
		return EnableUserDAO.EnableUser();
	}

	
		public static Boolean UpdateUser(Integer userid)
		{
		
			return EnableUserDAO.UpdateUser(userid);
		}

	

}