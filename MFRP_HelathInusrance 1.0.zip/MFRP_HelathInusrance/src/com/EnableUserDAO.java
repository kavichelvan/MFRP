package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;


public class EnableUserDAO {
	static Connection con;
	static{
	try {
		Class.forName("com.mysql.jdbc.Driver");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	try {
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Healthinsurance","root","root");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	public static ArrayList<UserPOJO> EnableUser()
	{
		ArrayList<UserPOJO> pojoList=new ArrayList<>();
		
		try {
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select user_id from login where status='Inactive';");
			while(rs.next())
			{
				UserPOJO eu=new UserPOJO(rs.getString(1));
				pojoList.add(eu);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return pojoList;
	}
	public static Boolean UpdateUser(Integer userid) {
		Statement st;
		Boolean rs=false;
		try {
			st = con.createStatement();
			Integer s=st.executeUpdate("update login set status='Active' where user_id="+userid+";"); 
			if(s>0)
				rs=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return rs;
	}

}
