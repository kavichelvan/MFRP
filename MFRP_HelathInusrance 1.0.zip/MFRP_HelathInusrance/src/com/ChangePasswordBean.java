package com;

public class ChangePasswordBean {
	public static String changePassword(ChangePasswordPOJO changePasswordPOJO)
	{
		String flag="fail";
		String password=changePasswordPOJO.getPassword();
		String confirmPassword= changePasswordPOJO.getConfirmPassword();
		if(password.equals(confirmPassword))
		{
		flag= ChangePasswordDAO.changePassword(changePasswordPOJO);
		System.out.println(flag);
		}
	return flag;
	}

}
