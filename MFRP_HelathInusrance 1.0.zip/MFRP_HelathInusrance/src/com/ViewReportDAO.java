package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class ViewReportDAO {
	static Connection con;
	static{
	try {
		Class.forName("com.mysql.jdbc.Driver");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	try {
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Healthinsurance","root","root");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	public static ArrayList<ReportPOJO> viewReport(ReportPOJO reportPOJO)
	{
		ArrayList<ReportPOJO> pojoList=new ArrayList<>();
		Integer user_id=reportPOJO.getUser_id();
		String fromdate1=reportPOJO.getFromDate();
		String todate1=reportPOJO.getToDate();
		
		try {
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from claims where user_id="+user_id+" and claim_date between '"+fromdate1+"' and '"+todate1+"';");
			while(rs.next())
			{
			
				ReportPOJO rpojo=new ReportPOJO(rs.getInt(1), user_id, rs.getString(3), rs.getDouble(4), rs.getString(5), fromdate1, todate1, rs.getString(6), rs.getString(7));
				pojoList.add(rpojo);
			}
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return pojoList;
	}
}
