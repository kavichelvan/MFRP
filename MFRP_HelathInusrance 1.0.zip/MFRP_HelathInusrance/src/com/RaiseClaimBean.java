package com;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class RaiseClaimBean {

      public static String claimRequest(RaiseClaimPOJO pojo)
      {
                        
            String error="";
           Boolean status_pattern=false;
            
            String check_amt=pojo.getClaim_amount();
           
            String pattern="[0-9]+";
          
            if(!(check_amt.matches(pattern))) 
        		   {
        	   status_pattern=true;
        		   }
           
            if(pojo.getClaim_type()==null && status_pattern)
            {
            	error="Claim Type: Please select a claim type<br>Claim Amount: Please enter Claim Amount";
            	return error;
            }
           if(pojo.getClaim_type()==null)
           {
        	   error="Claim Type: Please select a claim type";
        	   return error;
           }
           if(check_amt.equals(""))
           {
        	   error="Claim Amount: Please enter Claim Amount";
          	 return error;
           }
           //System.out.println((pattern.matches(check_amt)));
           if(!(check_amt.matches(pattern)))
           {
        	 error="Claim Amount: Only numbers are allowed";
        	 return error;
           }
           if(pojo.getClaim_description().equals(""))
           {
           	pojo.setClaim_description(" - - - - - - - -  ");
           }

           SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
           Date d=new Date();
           String currDate = sdf.format(d);
           
           String claimStatus="NOT APPROVED";
           
           pojo.setClaim_date(currDate);
           pojo.setClaim_status(claimStatus);
           error=RaiseClaimDAO.checkDB(pojo);
           return error;
            
            
            
      }
}
