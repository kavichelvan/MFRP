package com;

import java.util.Date;

public class RaiseClaimPOJO {
private String claimId;
public  String getClaimId() {
	return claimId;
}

public void setClaimId(String claimId) {
	this.claimId = claimId;
}
private Integer user_id;
private String claim_type;
private String claim_amount;
private String claim_description;
private String claim_date;
private String claim_status;
public RaiseClaimPOJO(Integer user_id, String claim_type, String claim_amount,
            String claim_description, String claim_date, String claim_status) {
      super();
      this.user_id = user_id;
      this.claim_type = claim_type;
      this.claim_amount = claim_amount;
      this.claim_description = claim_description;
      this.claim_date = claim_date;
      this.claim_status = claim_status;
}

public RaiseClaimPOJO(Integer user_id, String claim_type, String claim_amount,
            String claim_description) {
      super();
      this.user_id = user_id;
      this.claim_type = claim_type;
      this.claim_amount = claim_amount;
      this.claim_description = claim_description;
}

public Integer getUser_id() {
      return user_id;
}
public void setUser_id(Integer user_id) {
      this.user_id = user_id;
}
public String getClaim_type() {
      return claim_type;
}
public void setClaim_type(String claim_type) {
      this.claim_type = claim_type;
}
public String getClaim_amount() {
      return claim_amount;
}
public void setClaim_amount(String claim_amount) {
      this.claim_amount = claim_amount;
}
public String getClaim_description() {
      return claim_description;
}
public void setClaim_description(String claim_description) {
      this.claim_description = claim_description;
}
public String getClaim_date() {
      return claim_date;
}
public void setClaim_date(String currDate) {
      this.claim_date = currDate;
}
public String getClaim_status() {
      return claim_status;
}
public void setClaim_status(String claim_status) {
      this.claim_status = claim_status;
}
public RaiseClaimPOJO() {
      super();
      // TODO Auto-generated constructor stub
}

}

