package com;

public class LoginBean {
	
	public static boolean checkUser(LoginPOJO login)
	{
		char[] cp=login.getPassword().toCharArray();
		char[] p=new char[cp.length];
		for(int i=0;i<login.getPassword().length();i++)
		{
			int a=cp[i];
			a++;
			p[i]=(char)a;
		}
		String password=String.valueOf(p);
		login.setPassword(password);		
		return LoginDAO.checkUser(login);
		
	}
	
	public static String getRole(String userId)
	{
	 return LoginDAO.getRole(userId);
	}

}